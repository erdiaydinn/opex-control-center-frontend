﻿import React from 'react';

function productImage(p = {}) {
  const url =
    p.image_url ||
    p.imageUrl ||
    p["Product Image URL"] ||
    p.product_image_url ||
    p.image;

  return /^https?:\/\//i.test(String(url || "")) ? url : "";
}

function skuOf(p = {}) {
  return String(p.sku || p.SKU || p.barcode || p.Barcodes || "").trim();
}

function productLocation(p = {}) {
  const aisle = p.aisle || p.aisle_id || "";
  const moduleNo = p.module || p.module_id || "";
  const shelfNo = p.shelf || p.shelf_no || "";
  const position = p.position || p.position_order || 0;

  return {
    aisle: String(aisle || "-"),
    module: String(moduleNo || "-"),
    shelf: String(shelfNo || "-"),
    position: Number(position || 0),
    label: [aisle, moduleNo ? `M${moduleNo}` : "", shelfNo ? `R${shelfNo}` : ""]
      .filter(Boolean)
      .join("-") || "-",
  };
}

function rowsFromProducts(products = []) {
  return (products || []).map((p) => {
    const loc = productLocation(p);

    return {
      raw: p,
      aisle: loc.aisle,
      module: loc.module,
      shelf: loc.shelf,
      position: loc.position,
      location: loc.label,
      sku: skuOf(p),
      name: p.name || p.product_name || p.productName || p["Product Name"] || "-",
      brand: p.brand || p.brand_name || "-",
      category: p.category || p.category_l1 || p["Category L1"] || "-",
      storage: p.storage || p.storage_type || p.storage_class || "-",
      family: p.food_family || "-",
      facing: p.facing || p.facing_count || "-",
      depth: p.depth || "-",
      reason: p.placement_reason || "-",
      img: productImage(p),
    };
  });
}

function numSort(v) {
  const n = Number(v);
  return Number.isFinite(n) ? n : 9999;
}

function sortRows(rows = []) {
  return [...rows].sort((a, b) => {
    return (
      String(a.aisle).localeCompare(String(b.aisle), "tr") ||
      numSort(a.module) - numSort(b.module) ||
      numSort(a.shelf) - numSort(b.shelf) ||
      numSort(a.position) - numSort(b.position) ||
      String(a.name).localeCompare(String(b.name), "tr")
    );
  });
}

function groupByModule(rows = []) {
  const sorted = sortRows(rows);
  const modules = {};

  sorted.forEach((r) => {
    const moduleKey = `${r.aisle}__${r.module}`;
    modules[moduleKey] ||= {
      aisle: r.aisle,
      module: r.module,
      rows: [],
      shelves: {},
    };

    modules[moduleKey].rows.push(r);
    modules[moduleKey].shelves[r.shelf] ||= [];
    modules[moduleKey].shelves[r.shelf].push(r);
  });

  return Object.values(modules).sort((a, b) => {
    return (
      String(a.aisle).localeCompare(String(b.aisle), "tr") ||
      numSort(a.module) - numSort(b.module)
    );
  });
}

function csvEscape(value) {
  return `"${String(value ?? "").replaceAll('"', '""')}"`;
}

function downloadCsv(rows = []) {
  const sorted = sortRows(rows);

  const headers = [
    "Koridor",
    "Modül",
    "Raf",
    "Yeni Lokasyon",
    "SKU",
    "Ürün",
    "Marka",
    "Kategori",
    "Storage",
    "Food Family",
    "?ny?z",
    "Derinlik",
    "Neden",
  ];

  const csv = [
    headers.join(","),
    ...sorted.map((r) => [
      r.aisle,
      r.module,
      r.shelf,
      r.location,
      r.sku,
      r.name,
      r.brand,
      r.category,
      r.storage,
      r.family,
      r.facing,
      r.depth,
      r.reason,
    ].map(csvEscape).join(",")),
  ].join("\n");

  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "planogram_export.csv";
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

function productMiniCard(r) {
  return `
    <div class="product-mini">
      <div class="img-wrap">
        ${r.img ? `<img src="${r.img}" />` : `<div class="no-img">${String(r.name || "?").slice(0, 2)}</div>`}
      </div>
      <div class="p-name">${r.name}</div>
      <div class="p-sku">${r.sku}</div>
      <div class="p-meta">${r.storage} · F${r.facing} · D${r.depth}</div>
    </div>
  `;
}

function buildModuleBoardHtml(rows = []) {
  const modules = groupByModule(rows);

  return modules.map((mod) => {
    const shelfNumbers = Object.keys(mod.shelves).map(Number);
    const maxShelf = Math.max(6, ...shelfNumbers.filter(Number.isFinite));

    const shelfHtml = Array.from({ length: maxShelf }, (_, idx) => {
      const shelfNo = String(idx + 1);
      const items = sortRows(mod.shelves[shelfNo] || []);

      return `
        <div class="shelf-line">
          <div class="shelf-title">
            <b>RAF ${shelfNo}</b>
            <span>${items.length} SKU</span>
          </div>
          <div class="shelf-products">
            ${items.length ? items.map(productMiniCard).join("") : `<div class="empty-shelf">Boş / kontrol</div>`}
          </div>
        </div>
      `;
    }).join("");

    return `
      <section class="module-board">
        <div class="module-header">
          <div>
            <h2>Koridor ${mod.aisle} / Modül ${mod.module}</h2>
            <p>${mod.rows.length.toLocaleString("tr-TR")} SKU · Modül kontrol çıktısı</p>
          </div>
          <div class="module-badge">MODÜL PANOSU</div>
        </div>
        ${shelfHtml}
      </section>
    `;
  }).join("");
}

function buildShelfListHtml(rows = []) {
  const sorted = sortRows(rows);
  const grouped = sorted.reduce((acc, r) => {
    const key = `${r.aisle} / Modül ${r.module} / Raf ${r.shelf}`;
    acc[key] ||= [];
    acc[key].push(r);
    return acc;
  }, {});

  return Object.entries(grouped).map(([key, items]) => `
    <section class="shelf-card">
      <h3>${key}</h3>
      <div class="visual-row">
        ${items.map(productMiniCard).join("")}
      </div>
    </section>
  `).join("");
}

function buildTextTableHtml(rows = []) {
  const sorted = sortRows(rows);

  return `
    <table>
      <thead>
        <tr>
          <th>Lokasyon</th>
          <th>SKU</th>
          <th>Ürün</th>
          <th>Marka</th>
          <th>Storage</th>
          <th>Family</th>
          <th>?ny?z</th>
          <th>Derinlik</th>
          <th>Neden</th>
        </tr>
      </thead>
      <tbody>
        ${sorted.map((r) => `
          <tr>
            <td>${r.location}</td>
            <td>${r.sku}</td>
            <td>${r.name}</td>
            <td>${r.brand}</td>
            <td>${r.storage}</td>
            <td>${r.family}</td>
            <td>${r.facing}</td>
            <td>${r.depth}</td>
            <td>${r.reason}</td>
          </tr>
        `).join("")}
      </tbody>
    </table>
  `;
}

function buildPrintHtml(rows = [], mode = "both", title = "Planogram", view = "module-board") {
  const sorted = sortRows(rows);
  const showVisual = mode === "visual" || mode === "both";
  const showText = mode === "text" || mode === "both";

  const visualHtml = showVisual
    ? view === "shelf-list"
      ? buildShelfListHtml(sorted)
      : buildModuleBoardHtml(sorted)
    : "";

  const textHtml = showText ? buildTextTableHtml(sorted) : "";

  return `
<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<title>${title}</title>
<style>
  @page { size: A4 landscape; margin: 9mm; }

  body {
    font-family: Arial, sans-serif;
    margin: 0;
    color: #111827;
    background: #fff;
  }

  h1 {
    margin: 0 0 4px;
    font-size: 24px;
  }

  .cover {
    padding: 10px 0 14px;
    border-bottom: 2px solid #111827;
    margin-bottom: 12px;
  }

  .meta {
    color: #64748b;
    font-size: 12px;
  }

  .module-board {
    page-break-after: always;
    break-after: page;
    border: 2px solid #111827;
    border-radius: 14px;
    padding: 12px;
    margin-bottom: 14px;
  }

  .module-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 12px;
    border-bottom: 1px solid #cbd5e1;
    padding-bottom: 8px;
    margin-bottom: 8px;
  }

  .module-header h2 {
    margin: 0;
    font-size: 22px;
  }

  .module-header p {
    margin: 4px 0 0;
    color: #64748b;
    font-size: 12px;
  }

  .module-badge {
    border: 1px solid #111827;
    border-radius: 999px;
    padding: 6px 10px;
    font-weight: 800;
    font-size: 11px;
  }

  .shelf-line {
    display: grid;
    grid-template-columns: 82px 1fr;
    gap: 10px;
    border-bottom: 1px solid #e5e7eb;
    padding: 7px 0;
    min-height: 96px;
  }

  .shelf-line:last-child {
    border-bottom: 0;
  }

  .shelf-title {
    display: flex;
    flex-direction: column;
    justify-content: center;
    gap: 4px;
    font-size: 13px;
  }

  .shelf-title span {
    color: #64748b;
    font-size: 11px;
  }

  .shelf-products,
  .visual-row {
    display: flex;
    flex-wrap: wrap;
    gap: 7px;
    align-items: stretch;
  }

  .product-mini {
    width: 92px;
    min-height: 86px;
    border: 1px solid #cbd5e1;
    border-radius: 10px;
    padding: 6px;
    display: grid;
    grid-template-rows: 28px auto auto auto;
    gap: 2px;
    background: #fff;
  }

  .img-wrap {
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .product-mini img {
    width: 26px;
    height: 26px;
    object-fit: contain;
  }

  .no-img {
    width: 26px;
    height: 26px;
    border-radius: 7px;
    background: #fce7f3;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 800;
    font-size: 9px;
  }

  .p-name {
    font-size: 8.5px;
    font-weight: 800;
    line-height: 1.15;
    max-height: 30px;
    overflow: hidden;
  }

  .p-sku {
    font-size: 8px;
    color: #64748b;
    line-height: 1.1;
  }

  .p-meta {
    font-size: 8.5px;
    color: #111827;
    line-height: 1.15;
    font-weight: 800;
  }

  .empty-shelf {
    border: 1px dashed #cbd5e1;
    border-radius: 10px;
    min-width: 160px;
    min-height: 68px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #94a3b8;
    font-size: 12px;
    font-weight: 700;
  }

  .shelf-card {
    page-break-inside: avoid;
    border: 1px solid #e5e7eb;
    border-radius: 14px;
    padding: 12px;
    margin-bottom: 14px;
  }

  .shelf-card h3 {
    margin: 0 0 10px;
    font-size: 15px;
  }

  table {
    width: 100%;
    border-collapse: collapse;
    font-size: 10px;
    margin-top: 14px;
  }

  th {
    text-align: left;
    background: #f8fafc;
    color: #475569;
  }

  th, td {
    border-bottom: 1px solid #e5e7eb;
    padding: 6px;
    vertical-align: top;
  }

  @media print {
    .module-board {
      break-inside: avoid;
    }
  }
</style>
</head>
<body>
  <div class="cover">
    <h1>${title}</h1>
    <div class="meta">${sorted.length.toLocaleString("tr-TR")} ürün · ${new Date().toLocaleString("tr-TR")}</div>
  </div>

  ${visualHtml}
  ${textHtml}
</body>
</html>
`;
}

function openPrintWindow(rows, mode, title, view) {
  const html = buildPrintHtml(rows, mode, title, view);
  const win = window.open("", "_blank");

  if (!win) {
    alert("Popup engellendi. Tarayıcıdan popup izni verip tekrar dene.");
    return;
  }

  win.document.open();
  win.document.write(html);
  win.document.close();

  setTimeout(() => {
    win.focus();
    win.print();
  }, 600);
}

function downloadHtml(rows, mode, title, view) {
  const html = buildPrintHtml(rows, mode, title, view);
  const blob = new Blob([html], { type: "text/html;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "planogram_module_board.html";
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

export default function PlanogramExportPanel({ products = [] }) {
  const [scope, setScope] = React.useState("all");
  const [mode, setMode] = React.useState("visual");
  const [view, setView] = React.useState("module-board");
  const [aisle, setAisle] = React.useState("");
  const [moduleNo, setModuleNo] = React.useState("");
  const [shelfNo, setShelfNo] = React.useState("");

  const allRows = rowsFromProducts(products);

  const rows = allRows.filter((r) => {
    if (scope === "all") return true;

    if (scope === "aisle") {
      return String(r.aisle).toUpperCase() === String(aisle).trim().toUpperCase();
    }

    if (scope === "module") {
      return (
        String(r.aisle).toUpperCase() === String(aisle).trim().toUpperCase() &&
        String(r.module) === String(moduleNo).trim()
      );
    }

    if (scope === "shelf") {
      return (
        String(r.aisle).toUpperCase() === String(aisle).trim().toUpperCase() &&
        String(r.module) === String(moduleNo).trim() &&
        String(r.shelf) === String(shelfNo).trim()
      );
    }

    return true;
  });

  const title =
    scope === "all"
      ? "Tüm Planogram - Modül Kontrol Panoları"
      : scope === "aisle"
        ? `Koridor ${aisle} - Modül Kontrol Panoları`
        : scope === "module"
          ? `Koridor ${aisle} / Modül ${moduleNo}`
          : `Koridor ${aisle} / Modül ${moduleNo} / Raf ${shelfNo}`;

  return (
    <section className="card pad planogram-export-panel">
      <div>
        <div className="section-eyebrow">PLANOGRAM ÇIKTI MERKEZİ</div>
        <h3>Modül panosu / yazdır / indir</h3>
        <p className="muted">
          Saha ekibi için modül bazlı çıktı üretir. Kağıt modülün önüne asılır; her raf tek ekranda hızlı kontrol edilir.
        </p>
      </div>

      <div className="export-grid">
        <label>
          Kapsam
          <select value={scope} onChange={(e) => setScope(e.target.value)}>
            <option value="all">Tüm planogram</option>
            <option value="aisle">Koridor</option>
            <option value="module">Tek modül</option>
            <option value="shelf">Tek raf</option>
          </select>
        </label>

        <label>
          Görünüm
          <select value={view} onChange={(e) => setView(e.target.value)}>
            <option value="module-board">Modül panosu</option>
            <option value="shelf-list">Raf listesi</option>
          </select>
        </label>

        <label>
          Format
          <select value={mode} onChange={(e) => setMode(e.target.value)}>
            <option value="visual">Sadece resimli</option>
            <option value="both">Yazılı + resimli</option>
            <option value="text">Sadece yazılı</option>
          </select>
        </label>

        {scope !== "all" && (
          <label>
            Koridor
            <input value={aisle} onChange={(e) => setAisle(e.target.value)} placeholder="A" />
          </label>
        )}

        {(scope === "module" || scope === "shelf") && (
          <label>
            Modül
            <input value={moduleNo} onChange={(e) => setModuleNo(e.target.value)} placeholder="2" />
          </label>
        )}

        {scope === "shelf" && (
          <label>
            Raf
            <input value={shelfNo} onChange={(e) => setShelfNo(e.target.value)} placeholder="1" />
          </label>
        )}
      </div>

      <div className="export-actions">
        <button className="btn primary" onClick={() => openPrintWindow(rows, mode, title, view)}>
          Yazdır / PDF kaydet
        </button>
        <button className="btn ghost" onClick={() => downloadHtml(rows, mode, title, view)}>
          HTML indir
        </button>
        <button className="btn ghost" onClick={() => downloadCsv(rows)}>
          CSV indir
        </button>
        <span className="muted">{rows.length.toLocaleString("tr-TR")} ürün seçili</span>
      </div>
    </section>
  );
}
