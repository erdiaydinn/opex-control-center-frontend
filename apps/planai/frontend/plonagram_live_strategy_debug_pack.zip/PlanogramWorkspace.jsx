import { useMemo, useState } from 'react';
import { tt } from '../i18n/dictionary.js';
import ShelfModal from './ShelfModal.jsx';
import { ProductChip, storageTone } from './ProductVisuals.jsx';
import TwinStudio3D from './Live3D/TwinStudio3D.jsx';
import { moduleShelfCount, productsForShelf } from '../utils/planogramAllocatorV2.js';

function escapeCsv(value) {
  const raw = String(value ?? '').replace(/\r?\n/g, ' ');
  return /[",;\t]/.test(raw) ? `"${raw.replace(/"/g, '""')}"` : raw;
}

function downloadText(filename, content, type = 'text/csv;charset=utf-8') {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

function unplacedRows(unplacedProducts = []) {
  return (unplacedProducts || []).map((p) => ({
    sku: p.sku || '',
    product: p.name || p.product_name || '',
    brand: p.brand || '',
    storage: p.storage || p.storage_type || '',
    reason: p.reason || p.constraint_reason || '',
    action: p.suggested_action || 'Fixture kapasitesi, storage type ve ürün ölçüsünü kontrol et.',
  }));
}

export default function PlanogramWorkspace({ lang, objects, products, setProducts, unplacedProducts = [], notify }) {
  const [open, setOpen] = useState('A');
  const [view, setView] = useState('2d');
  const [heat, setHeat] = useState('sales');
  const [modalShelf, setModalShelf] = useState(null);
  const corridors = useMemo(() => objects.filter((o) => Number(o.modules || 0) > 0 && Number(o.shelves || 0) > 0), [objects]);
  const modules = corridors.reduce((s,o)=>s+Number(o.modules||0),0);
  const shelves = corridors.reduce((s,o)=>s+Number(o.shelves||0),0);
  function updateProduct(sku, patch, show = true) {
    setProducts((prev) => prev.map((p) => p.sku === sku ? { ...p, ...patch } : p));
    if (show) notify?.('Raf içi düzen güncellendi.');
  }
  function addProduct(product, shelf) {
    updateProduct(product.sku, { aisle: shelf.aisle, aisle_id: shelf.aisle, module: shelf.moduleNo, module_id: shelf.moduleNo, shelf: shelf.shelfNo, shelf_no: shelf.shelfNo });
  }
  function addModule(c) {
    notify?.(`${c.label} koridoruna yeni modül eklendi.`);
  }

  function downloadUnplacedCsv() {
    const rows = unplacedRows(unplacedProducts);
    const head = ['SKU', 'Ürün', 'Marka', 'Storage', 'Neden', 'Aksiyon'];
    const body = rows.map((r) => [r.sku, r.product, r.brand, r.storage, r.reason, r.action].map(escapeCsv).join(';'));
    downloadText('atanamayan_urun_raporu.csv', [head.join(';'), ...body].join('\n'));
    notify?.('Atanamayan ürün raporu CSV olarak indirildi.');
  }

  function downloadUnplacedExcel() {
    const rows = unplacedRows(unplacedProducts);
    const table = `<table><thead><tr><th>SKU</th><th>Ürün</th><th>Marka</th><th>Storage</th><th>Neden</th><th>Aksiyon</th></tr></thead><tbody>${rows.map((r) => `<tr><td>${r.sku}</td><td>${r.product}</td><td>${r.brand}</td><td>${r.storage}</td><td>${r.reason}</td><td>${r.action}</td></tr>`).join('')}</tbody></table>`;
    downloadText('atanamayan_urun_raporu.xls', table, 'application/vnd.ms-excel;charset=utf-8');
    notify?.('Atanamayan ürün raporu Excel uyumlu dosya olarak indirildi.');
  }
  const kpis = [['Koridor', corridors.length], ['Modül', modules], ['Raf', shelves], ['Doluluk', '87%'], ['Yerleşen SKU', products.length.toLocaleString('tr-TR')], ['Atanamayan', unplacedProducts.length.toLocaleString('tr-TR')]];
  return (
    <div className="page">
      <div style={{ display:'flex', justifyContent:'space-between', gap:12, flexWrap:'wrap' }}>
        <div><div className="section-eyebrow">PLANOGRAM ÇALIŞMA ALANI</div><h1 style={{fontSize:42,margin:'8px 0'}}>{tt(lang,'planogram')}</h1><p className="page-sub">Koridor, modül, raf ve SKU düzeyinde uygulanabilir planogram.</p></div>
        <div className="tabs"><button className={`tab ${view==='3d'?'active':''}`} onClick={() => setView('3d')}>3D Görünüm</button><button className={`tab ${view==='2d'?'active':''}`} onClick={() => setView('2d')}>2D Planogram</button><button className={`tab ${view==='heatmap'?'active':''}`} onClick={() => setView('heatmap')}>Isı Haritası</button><button className={`tab ${view==='unplaced'?'active':''}`} onClick={() => setView('unplaced')}>Atanamayanlar</button></div>
      </div>
      <section className="grid cols-6" style={{ marginTop: 18 }}>{kpis.map(([l,v])=><div className="card kpi" key={l}><div className="kpi-label">{l}</div><div className="kpi-value">{v}</div><div className="kpi-trend">Toplam</div></div>)}</section>
      {view === 'heatmap' && <div className="card pad" style={{ marginTop: 18 }}><div className="tabs">{['sales','refill','cold'].map(h=><button className={`tab ${heat===h?'active':''}`} onClick={()=>setHeat(h)} key={h}>{h==='sales'?'Satış':h==='refill'?'Refill Risk':'Cold Chain'}</button>)}</div><div className="grid cols-3" style={{ marginTop: 16 }}>{corridors.map(c=><div key={c.id} className={`card pad heat-${heat}-bg`}><h3>{c.label}</h3><p>{tt(lang,'fill')}: {c.utilization}%</p><p>{tt(lang,'changedProducts')}: {c.changed}</p></div>)}</div></div>}
      {view === '3d' && <div className="planogram-3d card" style={{ marginTop: 18 }}><TwinStudio3D objects={objects} products={products.slice(0, 500)} cameraPreset="overview" heatmap={heat} selectedAreaId={open || 'A'} selectedProductSku="" onSelectArea={(area)=>setOpen(area.id)} onSelectProduct={(p)=>notify?.(`${p.name} seçildi.`)} /></div>}
      {view === 'unplaced' && <section className="card pad" style={{ marginTop: 18 }}>
        <div className="report-head"><div><h2>Atanamayan ürün raporu</h2><p className="muted">Fixture/storage/kapasite nedeniyle yerleşemeyen ürünler. Bu liste saha aksiyonuna dönüştürülmeli.</p></div><div className="report-actions"><button className="btn ghost" onClick={downloadUnplacedCsv}>CSV indir</button><button className="btn ghost" onClick={downloadUnplacedExcel}>Excel indir</button></div></div>
        <table className="table"><thead><tr><th>SKU</th><th>Ürün</th><th>Marka</th><th>Storage</th><th>Neden</th><th>Aksiyon</th></tr></thead><tbody>{unplacedRows(unplacedProducts).slice(0, 300).map((p, i)=><tr key={`${p.sku}-${i}`}><td>{p.sku}</td><td>{p.product}</td><td>{p.brand}</td><td><span className={`badge ${storageTone(p.storage)}`}>{p.storage}</span></td><td>{p.reason}</td><td>{p.action}</td></tr>)}</tbody></table>{!unplacedProducts.length && <div className="empty-state">Atanamayan ürün yok.</div>}{unplacedProducts.length > 300 && <p className="muted" style={{ marginTop: 12 }}>Ekranda ilk 300 satır gösteriliyor; indirilen dosyada tüm kayıtlar var.</p>}
      </section>}
      {view === '2d' && <section className="card pad" style={{ marginTop: 18 }}>
        {corridors.map((c) => {
          const moduleCount = Math.max(1, Number(c.modules || 1));
          const shelfPerModule = Math.max(1, Math.ceil(Number(c.shelves || moduleCount * 5) / moduleCount));
          return <div key={c.id} style={{ borderBottom: '1px solid var(--line)', padding: '14px 0' }}>
            <button className="item" style={{ width: '100%' }} onClick={() => setOpen(open === c.id ? '' : c.id)}>
              <div><b>{c.label}</b> <span className={`badge ${c.zone === 'FROZEN' ? 'purple' : c.zone === 'CHILLED' ? 'cyan' : 'green'}`}>{c.zone}</span></div>
              <div className="muted">{c.modules} Modül • Doluluk {c.utilization}% • {products.filter(p => String(p.aisle) === String(c.id)).length} SKU</div>
            </button>
            {open === c.id && <div className="planogram-row" style={{ marginTop: 14, overflowX: 'auto', paddingBottom: 10 }}>
              {Array.from({ length: moduleCount }, (_, i) => i + 1).map((m) => <div className="card module-card" key={`${c.id}-${m}`}><b>Modül {c.label}.{m}</b><span className="badge pink" style={{ marginLeft: 8 }}>{c.type === 'chilled_room' || c.type === 'frozen_room' ? '150' : '100'} cm</span>{Array.from({ length: Math.max(shelfPerModule, moduleShelfCount(products, c.id, m)) }, (_, si) => si + 1).map((s) => { const ps = productsForShelf(products, c.id, m, s).sort((a,b)=>Number(a.position||0)-Number(b.position||0)); return <button className="shelf" key={s} onClick={() => setModalShelf({ title: `${c.label} / Modül ${c.label}.${m} / Raf ${s}`, aisle: c.id, moduleId: `${c.label}.${m}`, moduleNo: m, shelfNo: s, shelf_width_cm: c.type === 'produce_shelf' ? 120 : c.type === 'chilled_room' || c.type === 'frozen_room' ? 150 : 100, shelf_depth_cm: c.type === 'produce_shelf' ? 60 : c.type === 'chilled_room' ? 55 : c.type === 'frozen_room' ? 60 : 50, products: ps })} style={{ width:'100%' }}><small className="shelf-label">Raf {c.label}.{m}.{s}</small>{ps.slice(0, 18).map((p) => <ProductChip key={p.sku} product={p} />)}{ps.length > 18 && <span className="more-chip">+{ps.length-18}</span>}{!ps.length && <span className="muted">Boş</span>}</button>; })}</div>)}
              <div className="card pad" style={{ display: 'grid', placeItems: 'center', borderStyle: 'dashed' }}><button className="btn ghost" onClick={() => addModule(c)}>＋ Modül</button></div>
            </div>}
          </div>;
        })}
      </section>}
      <ShelfModal lang={lang} shelf={modalShelf} products={products} onClose={() => setModalShelf(null)} onUpdateProduct={updateProduct} onAddProduct={addProduct} notify={notify} />
    </div>
  );
}
