# PLONAGRAM v1.8 — Catalog + SKU Library + Rule Engine Patch

Bu patch üç hatayı hedefler:

1. **SKU yükleyince Product Library / SKU kütüphanesine düşmüyor.**
   - Eski `/upload-products-csv` sadece zenginleştirilmiş ürünleri response içinde döndürüyordu.
   - Product Library ise `/master-products` üzerinden `backend/data/master_products.csv` dosyasını okuyordu.
   - Bu yüzden ekranda yükleme başarılı gibi görünse bile kütüphane eski dosyada kalıyordu.
   - Yeni endpoint upload sonrası CSV'yi `backend/data/master_products.csv` olarak kaydeder ve master cache'i yeniler.

2. **Kural motoru ana sayfada görünmüyor.**
   - `RuleEngineHomePanel.jsx` Command Center içine konacak hafif ama görünür kural motoru panelidir.
   - Detaylı Rule Engine yine ayrı ekranda kalabilir ama kullanıcı ana ekranda motorun nerede olduğunu görür.

3. **Catalog zaten storage/brand/raf/dolap bilgisi veriyor ama engine yanlış yerleştiriyor.**
   - `storage_type` artık açık catalog değeri varsa onu değiştirilemez gerçek kabul eder.
   - `storage_raw` fiziksel fixture'a çevrilir: `Raf -> SHELF`, `Dolap -> FRIDGE`, `Donuk/-18/Algida -> FREEZER`.
   - `can_place` artık sadece storage değil, fixture uygunluğu da kontrol eder.
   - Gıda/gıda dışı aynı koridora/rafa karışmaz.
   - Aynı rafta kategori karışımı engellenir; marka gruplaması skor tarafında güçlenir.

## Değiştirilecek backend dosyaları

Aşağıdaki dosyaları mevcut backend klasöründe aynı isimlerle değiştir:

```text
backend/main.py
backend/engine.py
backend/master_products_api.py
```

> Eğer senin yapında backend dosyaları `backend/backend` altındaysa aynı mantıkla oraya kopyala.

## Eklenecek frontend dosyaları

```text
frontend/src/services/plonagramCatalogApi.js
frontend/src/components/SkuUploadButton.jsx
frontend/src/components/RuleEngineHomePanel.jsx
frontend/src/styles/catalog-rule-engine.css
```

## App.jsx entegrasyonu

### 1) Import ekle

```jsx
import SkuUploadButton from "./components/SkuUploadButton";
import RuleEngineHomePanel from "./components/RuleEngineHomePanel";
```

### 2) State ekle

```jsx
const [skuLibrary, setSkuLibrary] = useState(() => {
  try {
    return JSON.parse(localStorage.getItem("plonagram.skuLibrary") || "[]");
  } catch {
    return [];
  }
});

const [placementRules, setPlacementRules] = useState(() => {
  try {
    return JSON.parse(localStorage.getItem("plonagram.ruleEngine") || "{}");
  } catch {
    return {};
  }
});
```

### 3) TopBar veya Command Center üst alana SKU upload bağla

```jsx
<SkuUploadButton
  setStatus={setStatus}
  setProducts={setProducts}
  setSkuLibrary={setSkuLibrary}
  onUploaded={({ products }) => {
    setActiveView?.("product-library");
  }}
/>
```

### 4) Command Center içine kural panelini koy

```jsx
<RuleEngineHomePanel
  value={placementRules}
  onChange={setPlacementRules}
  onOpenFullRuleEngine={() => setActiveView?.("rule-engine")}
/>
```

### 5) Optimize çağrısında SKU kaynağını doğru ver

```js
const sourceProducts = skuLibrary.length ? skuLibrary : products;

const payload = {
  products: sourceProducts,
  layout: planogram,
  mode: placementRules?.mode || "HYBRID",
  scoring_config: placementRules?.scoring_config,
  brand_side_rules: placementRules?.brand_side_rules,
  allow_ai_dimensions: true,
};

const result = await api.generatePlanogram(payload);
```

## Çalıştırma

Backend:

```bash
cd backend
python -m pip install -r requirements.txt
python -m uvicorn main:app --host 127.0.0.1 --port 8001 --reload
```

Frontend:

```bash
cd frontend
npm install
npm run dev
```

## Smoke test

Patch paketinin kökünde:

```bash
python test_catalog_engine_patch.py
```

Beklenen çıktı:

```text
OK - catalog/fixture/storage placement works
('YS2915', 'AMBIENT', 'SHELF', 'A', 'regular_shelf')
('YS2938', 'CHILLED', 'FRIDGE', 'MARTEK+4', 'fridge')
('FROZEN_TEST', 'FROZEN', 'FREEZER', 'MARTEK-18', 'freezer')
```

## Kontrol listesi

- SKU yüklemeden sonra `/master-products?limit=10` yeni ürünleri göstermeli.
- `/reload-master` sonrası `master_rows` yüklenen CSV satır sayısına yakın olmalı.
- `/generate-planogram` response içinde CHILLED ürünler sadece fridge/chilled shelf'e gitmeli.
- FROZEN ürünler sadece freezer/frozen shelf'e gitmeli.
- AMBIENT + `storage_raw=Raf` ürünler fridge/freezer'a düşmemeli.
- Product Library sayfası `skuLibrary` state'inden veya `/master-products` endpointinden beslenmeli.
- Command Center içinde Kural Motoru görünür olmalı.
