"""Smoke test for PLONAGRAM v1.8 Catalog + Rule Engine patch.
Run from package root:
  python test_catalog_engine_patch.py
"""
import sys
from pathlib import Path

backend = Path(__file__).resolve().parent / "backend"
sys.path.insert(0, str(backend))

from engine import enrich_product, fixture_kind, generate_default_layout, generate_planogram, validate_planogram

sample_products = [
    {
        "sku": "YS2915",
        "product_name": "Organuca Zencefilli İçecek Ginger Shot 3 x 60 ml",
        "brand_name": "Organuca",
        "brand": "Organuca",
        "storage_type": "AMBIENT",
        "storage_raw": "Raf",
        "frontend_category_local": "Beverage",
        "frontend_subcategory_local": "Soft Drink / Juice",
        "category_l1": "Beverage",
        "category_l2": "Soft Drink / Juice",
        "width_cm": 4.4,
        "depth_cm": 12.75,
        "height_cm": 8.5,
        "weight_kg": 0.43,
    },
    {
        "sku": "YS2938",
        "product_name": "Milagro Dikenli İncir 1 Adet",
        "brand_name": "Milagro",
        "brand": "Milagro",
        "storage_type": "CHILLED",
        "storage_raw": "Dolap",
        "frontend_category_local": "Food Chilled",
        "frontend_subcategory_local": "Chilled General",
        "category_l1": "Food Chilled",
        "category_l2": "Chilled General",
        "width_cm": 2,
        "depth_cm": 2,
        "height_cm": 4,
        "weight_kg": 0.05,
    },
    {
        "sku": "FROZEN_TEST",
        "product_name": "Algida Test Ürün",
        "brand_name": "Algida",
        "brand": "Algida",
        "storage_type": "FROZEN",
        "storage_raw": "Donuk",
        "frontend_category_local": "Frozen",
        "frontend_subcategory_local": "Ice Cream",
        "width_cm": 10,
        "depth_cm": 10,
        "height_cm": 10,
        "weight_kg": 0.2,
    },
]

for p in sample_products:
    ep = enrich_product(p)
    assert ep["storage_type"] in {"AMBIENT", "CHILLED", "FROZEN"}, ep
    assert fixture_kind(ep) in {"SHELF", "FRIDGE", "FREEZER"}, ep

result = generate_planogram(sample_products, generate_default_layout())
assert result["summary"]["placed_products"] == 3, result["summary"]
violations = validate_planogram(result["planogram"])["summary"]
assert violations["strict_rule_violation_count"] == 0, violations

placements = []
for aisle in result["planogram"].get("aisles", []):
    for module in aisle.get("modules", []):
        for shelf in module.get("shelves", []):
            for product in shelf.get("products", []):
                placements.append((product["sku"], product["storage_type"], product.get("fixture_kind"), aisle["aisle_id"], module["module_type"]))

print("OK - catalog/fixture/storage placement works")
for row in placements:
    print(row)
