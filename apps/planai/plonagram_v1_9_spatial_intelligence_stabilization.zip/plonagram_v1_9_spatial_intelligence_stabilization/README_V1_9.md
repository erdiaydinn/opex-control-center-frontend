# PLONAGRAM V1.9 Spatial Intelligence Stabilization

Bu sürüm önceki yamalarda bozulan temel akışı ayağa kaldırmak için hazırlanmıştır.

## Ne getirir?

### Backend

- `storage_raw` birincil fixture kuralı
- `case_pack_qty` tam koli rounding
- ürün bazlı güven skoru
- planogram score
- AI güven skoru
- council decision
- raf değişim / boş alan etki analizi

### Frontend

- Command Center içinde gerçek kural motoru paneli
- Product Library backend catalog okur, Enter ile arama çalışır
- Shelf Impact Studio: FIFA tarzı ürün değişim kıyası
- Store DNA Builder: sol/sağ yüz, farklı modül ve raf sayısı
- Merkezi TR/EN/DE/AR sözlük
- UTF-8 bozuk metin yerine temiz Türkçe
- Güven skoru yazıcı çıktısında gizlenir

## Kurulum

ZIP'i aç, PowerShell'de:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
cd "<ZIP_ACILAN_KLASOR>\scripts"
.\install_plonagram_v1_9.ps1 -ProjectRoot "C:\Users\ErdiAydın\planai"
```

Sonra backend:

```powershell
cd "C:\Users\ErdiAydın\planai\backend"
python -m uvicorn main:app --host 127.0.0.1 --port 8001 --reload
```

Frontend:

```powershell
cd "C:\Users\ErdiAydın\planai\frontend"
npm run dev
```

## Kabul kapısı

Detaylar: `docs/V1_9_ACCEPTANCE_CRITERIA.md`

## Entegrasyon

Detaylar: `docs/INTEGRATION_GUIDE.md`
