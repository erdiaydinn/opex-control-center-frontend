# Plonagram V1.9 Integration Guide

Bu paket riskli otomatik App.jsx rewrite yapmaz. Çünkü mevcut frontend zaten yama birikimi yüzünden kırılgan. Paket güvenli şekilde yeni component ve backend endpointlerini ekler.

## Backend

Kurulum scripti `backend/main.py` sonuna şu router kaydını idempotent ekler:

```py
try:
    from intelligence_routes_v19 import router as intelligence_v19_router
    app.include_router(intelligence_v19_router)
except Exception as _plonagram_v19_route_error:
    print(f"[WARN] intelligence-v19 router not loaded: {_plonagram_v19_route_error}")
```

Test endpointleri:

- `POST /intelligence-v19/score-planogram`
- `POST /intelligence-v19/product-confidence`
- `POST /intelligence-v19/compare-shelf-change`
- `POST /intelligence-v19/sort-suggestions`

## Frontend importları

Yeni componentler:

```jsx
import CommandCenterV19 from "./components/CommandCenterV19";
import ProductLibraryV19 from "./components/ProductLibraryV19";
import ShelfImpactStudioV19 from "./components/ShelfImpactStudioV19";
import StoreDnaBuilderV19 from "./components/StoreDnaBuilderV19";
```

## Önerilen sayfa sırası

```txt
1. CommandCenterV19
2. StoreDnaBuilderV19
3. ProductLibraryV19
4. Fixture Library
5. Planogram Studio
6. ShelfImpactStudioV19
7. Live 3D
8. Delta
9. Publishing
10. Tasks / Photo Evidence
11. Reports
12. Admin
```

## Command Center içinde olması gerekenler

- Kural motoru
- storage_raw hard rule
- case_pack_qty hard rule
- Planogram Score
- AI Güven Skoru
- Council Kararı
- Catalog durumu
- ABC durumu
- Store DNA durumu

## Product Library

Mevcut mock `products` state’i yerine backend catalog okunmalı:

```jsx
<ProductLibraryV19 lang={lang} onProductsLoaded={(rows) => setProducts(rows)} />
```

Arama Enter ile çalışır.

## Shelf Impact

Raf açıldığında teknik ama yormayan ürün güven skoru gösterilir. Yazıcı çıktısında gizlenir.

```jsx
<ShelfImpactStudioV19
  lang={lang}
  shelf={selectedShelf}
  aisle={selectedAisle}
  module={selectedModule}
  currentProduct={selectedProduct}
  onApply={({ candidate, comparison }) => {
    // mevcut move/add-product endpointine bağla
  }}
/>
```

## Store DNA Builder

A koridoru gibi gerçek senaryoları destekler:

- Sol 3 modül / sağ 6 modül
- Her modülde farklı raf sayısı
- Her modülde farklı ölçü
- Çıktı: `layout.v2`

```jsx
<StoreDnaBuilderV19
  initialLayout={layout}
  onSave={(nextLayout) => setLayout(nextLayout)}
/>
```

## Kritik not

Bu paketin amacı mevcut bozuk UI'ı daha fazla yamamak değil, yeni sağlam çekirdeği yan yana eklemektir. Eski sayfalar tek tek bu componentlere taşınmalı.
