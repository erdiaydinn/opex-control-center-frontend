# Plonagram V1.9 Layout Schema V2

Amaç: 2D, 3D, engine ve depo kurulumunun aynı gerçekliği kullanması.

Eski model yetersizdi çünkü koridoru düz `modules[]` listesi gibi görüyordu. Gerçek depo ise:

- Koridor
- Sağ / sol yüz
- Modül
- Raf

şeklinde yaşar. Aynı koridorun solunda 3 modül, sağında 6 modül olabilir. Aynı yüzdeki modüllerin raf sayısı ve ölçüsü farklı olabilir.

## Canonical model

```json
{
  "store_code": "FULYA",
  "schema_version": "layout.v2",
  "aisles": [
    {
      "aisle_id": "A",
      "type": "double_sided",
      "position": { "x": 0, "y": 0, "rotation": 0 },
      "walkway_width_cm": 120,
      "faces": {
        "L": {
          "label": "A Sol",
          "modules": [
            {
              "module_id": "A-L-01",
              "fixture_type": "regular_shelf",
              "width_cm": 100,
              "depth_cm": 50,
              "height_cm": 210,
              "allowed_storage_type": "AMBIENT",
              "shelves": [
                { "shelf_no": 1, "width_cm": 100, "depth_cm": 50, "height_cm": 35, "max_weight_kg": 45, "products": [] },
                { "shelf_no": 2, "width_cm": 100, "depth_cm": 50, "height_cm": 35, "max_weight_kg": 45, "products": [] }
              ]
            }
          ]
        },
        "R": {
          "label": "A Sağ",
          "modules": []
        }
      }
    }
  ],
  "objects": [
    { "id": "col-1", "type": "column", "x": 4, "y": 8, "width_cm": 60, "depth_cm": 60, "height_cm": 300 }
  ]
}
```

## Kurallar

1. `shelf_count` sadece hızlı kurulum için kullanılır.
2. Engine gerçek yerleşimde daima `shelves[]` okur.
3. 2D render, 3D render ve engine aynı `layout.v2` objesinden beslenir.
4. Martek +4 varsayılan 2 modül sayılır.
5. `storage_raw` fixture hedefinde birinci kaynaktır.
6. `case_pack_qty` adet önerilerinde hard constraint olarak uygulanır.

