# V1.9 Stabilizasyon Kabul Kriterleri

Bu sürüm yalnızca güzel UI değildir. Kırılan ana akışı ayağa kaldırmak için kabul kapısıdır.

## Zorunlu kabul kriterleri

- Backend açılır.
- `/intelligence-v19/score-planogram` 200 döner.
- `/intelligence-v19/product-confidence` 200 döner.
- `/intelligence-v19/compare-shelf-change` 200 döner.
- SKU upload sonrası Product Library backend catalog okur.
- Product Library arama alanı Enter ile çalışır.
- Komuta Merkezi içinde kural motoru ve skorlar görünür.
- Türkçe karakterler bozulmaz.
- TR / EN / DE / AR sözlüğü merkezi dosyada durur.
- Ürün bazlı güven skoru ekranda ikincil bilgi olarak görünür.
- Ürün güven skoru yazıcı çıktısında görünmez.
- Öneri listeleri güven skoruna göre sıralanabilir.
- `storage_raw` öncelik kuralı uygulanır.
- `case_pack_qty` tam koli kuralı uygulanır.

## Bilerek kapsam dışı

- 3D render motorunun komple yenilenmesi.
- Mevcut tüm App.jsx route yapısının otomatik değiştirilmesi.
- Ollama gerçek bağlantısı.

Bunlar V1.9 sonrası yapılacak. Önce çekirdek akış sağlam olmalı.
