param(
  [string]$ProjectRoot = "",
  [string]$PatchRoot = ""
)

$ErrorActionPreference = "Stop"

function Find-ProjectRoot {
  if ($ProjectRoot -and (Test-Path $ProjectRoot)) { return (Resolve-Path $ProjectRoot).Path }

  $candidates = @(
    (Join-Path $env:USERPROFILE "planai"),
    (Join-Path $env:USERPROFILE "plonagram"),
    (Join-Path $env:USERPROFILE "opex-control-center-scaffold"),
    "C:\planai",
    "C:\plonagram"
  )
  foreach ($c in $candidates) {
    if (Test-Path (Join-Path $c "backend")) { return (Resolve-Path $c).Path }
  }

  $found = Get-ChildItem -Path "C:\Users" -Directory -ErrorAction SilentlyContinue |
    ForEach-Object { Join-Path $_.FullName "planai" } |
    Where-Object { Test-Path (Join-Path $_ "backend") } |
    Select-Object -First 1

  if ($found) { return (Resolve-Path $found).Path }
  throw "Project root bulunamadı. -ProjectRoot parametresiyle ver. Örnek: .\install_plonagram_v1_9.ps1 -ProjectRoot 'C:\Users\ErdiAydın\planai'"
}

function Find-PatchRoot {
  if ($PatchRoot -and (Test-Path $PatchRoot)) { return (Resolve-Path $PatchRoot).Path }
  $here = Split-Path -Parent $MyInvocation.MyCommand.Path
  $parent = Split-Path -Parent $here
  if (Test-Path (Join-Path $parent "backend\intelligence_core_v19.py")) { return $parent }
  if (Test-Path (Join-Path $here "backend\intelligence_core_v19.py")) { return $here }
  throw "Patch root bulunamadı. Script ZIP içindeki scripts klasöründen çalıştırılmalı."
}

$root = Find-ProjectRoot
$patch = Find-PatchRoot
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$backup = Join-Path $root "_backup_v19_$stamp"

Write-Host "== PLONAGRAM V1.9 SPATIAL INTELLIGENCE INSTALL =="
Write-Host "ProjectRoot: $root"
Write-Host "PatchRoot:   $patch"
Write-Host "Backup:      $backup"

New-Item -ItemType Directory -Force -Path $backup | Out-Null

$backendDir = Join-Path $root "backend"
$frontendDir = Join-Path $root "frontend"

if (!(Test-Path $backendDir)) { throw "Backend klasörü bulunamadı: $backendDir" }
if (!(Test-Path $frontendDir)) { throw "Frontend klasörü bulunamadı: $frontendDir" }

# Backend additive files
Copy-Item (Join-Path $patch "backend\intelligence_core_v19.py") (Join-Path $backendDir "intelligence_core_v19.py") -Force
Copy-Item (Join-Path $patch "backend\intelligence_routes_v19.py") (Join-Path $backendDir "intelligence_routes_v19.py") -Force

# Patch main.py idempotently
$main = Join-Path $backendDir "main.py"
Copy-Item $main (Join-Path $backup "main.py.bak") -Force
$mainText = Get-Content $main -Raw -Encoding UTF8
if ($mainText -notmatch "intelligence_routes_v19") {
  $block = @'

# ---- Plonagram V1.9 Spatial Intelligence routes ----
try:
    from intelligence_routes_v19 import router as intelligence_v19_router
    app.include_router(intelligence_v19_router)
except Exception as _plonagram_v19_route_error:
    print(f"[WARN] intelligence-v19 router not loaded: {_plonagram_v19_route_error}")
# ----------------------------------------------------
'@
  Add-Content -Path $main -Value $block -Encoding UTF8
  Write-Host "main.py içine intelligence-v19 router eklendi."
} else {
  Write-Host "main.py içinde intelligence-v19 zaten var."
}

# Frontend additive files
$componentDir = Join-Path $frontendDir "src\components"
$serviceDir = Join-Path $frontendDir "src\services"
$i18nDir = Join-Path $frontendDir "src\i18n"
$styleDir = Join-Path $frontendDir "src\styles"
New-Item -ItemType Directory -Force -Path $componentDir,$serviceDir,$i18nDir,$styleDir | Out-Null

Copy-Item (Join-Path $patch "frontend\src\components\CommandCenterV19.jsx") (Join-Path $componentDir "CommandCenterV19.jsx") -Force
Copy-Item (Join-Path $patch "frontend\src\components\ProductLibraryV19.jsx") (Join-Path $componentDir "ProductLibraryV19.jsx") -Force
Copy-Item (Join-Path $patch "frontend\src\components\ShelfImpactStudioV19.jsx") (Join-Path $componentDir "ShelfImpactStudioV19.jsx") -Force
Copy-Item (Join-Path $patch "frontend\src\components\StoreDnaBuilderV19.jsx") (Join-Path $componentDir "StoreDnaBuilderV19.jsx") -Force
Copy-Item (Join-Path $patch "frontend\src\services\plonagramV19Api.js") (Join-Path $serviceDir "plonagramV19Api.js") -Force
Copy-Item (Join-Path $patch "frontend\src\i18n\plonagramV19Dictionary.js") (Join-Path $i18nDir "plonagramV19Dictionary.js") -Force
Copy-Item (Join-Path $patch "frontend\src\styles\plonagram-v19.css") (Join-Path $styleDir "plonagram-v19.css") -Force

# Syntax checks
Push-Location $backendDir
python -m py_compile intelligence_core_v19.py intelligence_routes_v19.py main.py
Pop-Location

Write-Host "PATCH INSTALLED OK"
Write-Host "Backend test: http://127.0.0.1:8001/intelligence-v19/score-planogram"
Write-Host "Frontend components copied. Route entegrasyonu için docs/INTEGRATION_GUIDE.md dosyasına bak."
