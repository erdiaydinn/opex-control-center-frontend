from backend.intelligence_core_v19 import resolve_fixture_target, case_pack_rounded_units, product_placement_confidence, compare_shelf_change, score_planogram_intelligence


def test_storage_raw_priority():
    p = {"sku":"YS2915", "storage_raw":"Raf", "storage_type":"CHILLED"}
    r = resolve_fixture_target(p)
    assert r["storage_type"] == "AMBIENT"
    assert r["fixture_target"] == "SHELF"
    assert r["data_quality_warning"] == "storage_raw_storage_type_conflict"


def test_case_pack_rounding():
    assert case_pack_rounded_units(14, 12)["units"] == 24
    assert case_pack_rounded_units(8, 12)["units"] == 12
    assert case_pack_rounded_units(24, 12)["units"] == 24


def test_confidence_and_compare():
    shelf = {"shelf_no":1, "shelf_width_cm":100, "shelf_depth_cm":50, "shelf_height_cm":35, "products":[]}
    aisle = {"aisle_id":"A"}
    module = {"module_id":"A-L-01", "module_type":"regular_shelf"}
    p = {"sku":"YS2915", "product_name":"Test", "brand":"X", "category_l1":"Beverage", "category_l2":"Juice", "storage_raw":"Raf", "width_cm":5, "depth_cm":10, "height_cm":12, "case_pack_qty":12, "sales_qty_7d":48}
    conf = product_placement_confidence(p, aisle, module, shelf)
    assert conf["placement_confidence"] >= 75
    cmp = compare_shelf_change(shelf, None, p, aisle, module)
    assert cmp["status"] == "success"


def test_planogram_score():
    plan = {"aisles":[{"aisle_id":"A", "modules":[{"module_id":1, "module_type":"regular_shelf", "shelves":[{"shelf_no":1,"shelf_width_cm":100,"shelf_depth_cm":50,"shelf_height_cm":35,"products":[{"sku":"YS2915","product_name":"Test","brand":"X","category_l1":"Beverage","category_l2":"Juice","storage_raw":"Raf","width_cm":5,"depth_cm":10,"height_cm":12,"case_pack_qty":12}]}]}]}]}
    score = score_planogram_intelligence(plan)
    assert score["status"] == "success"
    assert score["product_count"] == 1
